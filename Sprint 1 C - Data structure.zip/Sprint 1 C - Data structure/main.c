#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

// Defini��o da estrutura para representar um dispositivo
typedef struct {
    char nome[50];
    float potencia;         // em Watts
    int horasUsoDiario;     // horas por dia
    int prioridade;         // 1 (alta) a 3 (baixa)
    bool estado;            // ligado/desligado
} Dispositivo;

// Fun��o para cadastrar um novo dispositivo
Dispositivo* cadastrarDispositivo(Dispositivo *lista, int *tamanho) {
    // Alocar espa�o para um dispositivo adicional
    Dispositivo *novaLista = realloc(lista, (*tamanho + 1) * sizeof(Dispositivo));

    if (novaLista == NULL) {
        printf("Erro ao alocar mem�ria!\n");
        return lista;
    }

    lista = novaLista;
    Dispositivo *novo = &lista[*tamanho];

    printf("\n--- Cadastro de Novo Dispositivo ---\n");

    printf("Nome do dispositivo: ");
    scanf("%49s", novo->nome);

    printf("Potencia (em Watts): ");
    scanf("%f", &novo->potencia);

    printf("Horas de uso diario: ");
    scanf("%d", &novo->horasUsoDiario);

    printf("Prioridade (1-Alta, 2-Media, 3-Baixa): ");
    scanf("%d", &novo->prioridade);

    novo->estado = false; // Inicialmente desligado

    (*tamanho)++;
    printf("Dispositivo cadastrado com sucesso!\n");

    return lista;
}

// Fun��o para calcular o consumo di�rio de um dispositivo
float calcularConsumoDiario(Dispositivo *d) {
    return (d->potencia * d->horasUsoDiario) / 1000.0; // kWh
}

// Fun��o para listar todos os dispositivos
void listarDispositivos(Dispositivo *lista, int tamanho) {
    printf("\n--- Lista de Dispositivos ---\n");
    printf("%-20s %-10s %-15s %-10s %-10s %-10s\n",
           "Nome", "Potencia", "Horas/Dia", "Prioridade", "Estado", "Consumo");

    float consumoTotal = 0;

    for (int i = 0; i < tamanho; i++) {
        float consumo = calcularConsumoDiario(&lista[i]);
        consumoTotal += consumo;

        printf("%-20s %-10.2f %-15d %-10d %-10s %-10.2f kWh\n",
               lista[i].nome,
               lista[i].potencia,
               lista[i].horasUsoDiario,
               lista[i].prioridade,
               lista[i].estado ? "Ligado" : "Desligado",
               consumo);
    }

    printf("\nConsumo total diario: %.2f kWh\n", consumoTotal);
}

// Fun��o para controlar dispositivos com base na prioridade
void controlarPorPrioridade(Dispositivo *lista, int tamanho, float limiteEnergia) {
    float consumoAtual = 0;

    // Primeiro desligamos tudo para come�ar do zero
    for (int i = 0; i < tamanho; i++) {
        lista[i].estado = false;
    }

    // Ligamos dispositivos por prioridade at� atingir o limite
    for (int prio = 1; prio <= 3 && consumoAtual < limiteEnergia; prio++) {
        for (int i = 0; i < tamanho; i++) {
            if (lista[i].prioridade == prio) {
                float consumo = calcularConsumoDiario(&lista[i]);

                if (consumoAtual + consumo <= limiteEnergia) {
                    lista[i].estado = true;
                    consumoAtual += consumo;
                } else {
                    lista[i].estado = false;
                }
            }
        }
    }

    printf("\nControle por prioridade aplicado (limite: %.2f kWh)\n", limiteEnergia);
    printf("Consumo total apos controle: %.2f kWh\n", consumoAtual);
}

// Fun��o para simular decis�o automatizada
void simularDecisao(Dispositivo *lista, int tamanho) {
    float consumoTotal = 0;
    for (int i = 0; i < tamanho; i++) {
        if (lista[i].estado) {
            consumoTotal += calcularConsumoDiario(&lista[i]);
        }
    }

    // Simula��o simples: se consumo > 10 kWh, sugere desligar dispositivos de baixa prioridade
    if (consumoTotal > 10.0) {
        printf("\n[Simulacao] Consumo alto (%.2f kWh). Recomendacao:\n", consumoTotal);
        printf("Desligar dispositivos de baixa prioridade para economizar energia.\n");

        for (int i = 0; i < tamanho; i++) {
            if (lista[i].prioridade == 3 && lista[i].estado) {
                printf("- Desligar %s (economia de %.2f kWh/dia)\n",
                       lista[i].nome, calcularConsumoDiario(&lista[i]));
            }
        }
    } else {
        printf("\n[Simulacao] Consumo dentro dos limites (%.2f kWh). Nenhuma acao necessaria.\n", consumoTotal);
    }
}

// Fun��o principal
int main() {
    Dispositivo *dispositivos = NULL;
    int numDispositivos = 0;
    int opcao;

    do {
        printf("\n--- Sistema de Controle de Energia Domestica ---\n");
        printf("1. Cadastrar novo dispositivo\n");
        printf("2. Listar dispositivos\n");
        printf("3. Controlar consumo por prioridade\n");
        printf("4. Simular decisao automatizada\n");
        printf("0. Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                dispositivos = cadastrarDispositivo(dispositivos, &numDispositivos);
                break;
            case 2:
                if (numDispositivos > 0) {
                    listarDispositivos(dispositivos, numDispositivos);
                } else {
                    printf("\nNenhum dispositivo cadastrado ainda.\n");
                }
                break;
            case 3:
                if (numDispositivos > 0) {
                    float limite;
                    printf("\nInforme o limite diario de consumo (em kWh): ");
                    scanf("%f", &limite);
                    controlarPorPrioridade(dispositivos, numDispositivos, limite);
                } else {
                    printf("\nNenhum dispositivo cadastrado ainda.\n");
                }
                break;
            case 4:
                if (numDispositivos > 0) {
                    simularDecisao(dispositivos, numDispositivos);
                } else {
                    printf("\nNenhum dispositivo cadastrado ainda.\n");
                }
                break;
            case 0:
                printf("\nEncerrando o programa...\n");
                break;
            default:
                printf("\nOpcao invalida!\n");
        }
    } while (opcao != 0);

    // Liberar mem�ria alocada
    free(dispositivos);

    return 0;
}
