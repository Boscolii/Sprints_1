#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

// Definicao da estrutura para representar um dispositivo
typedef struct {
    char nome[50];
    float potencia;         // em Watts
    float horasUsoDiario;     // horas por dia
    int prioridade;         // 1 (alta) a 3 (baixa)
    bool estado;            // ligado/desligado
} Dispositivo;

// Prot�tipos das fun��es
Dispositivo* cadastrarDispositivo(Dispositivo *lista, int *tamanho);
float calcularConsumoDiario(Dispositivo *d);
void listarDispositivos(Dispositivo *lista, int tamanho);
void controlarPorPrioridade(Dispositivo *lista, int tamanho, float limiteEnergia);
void simularDecisao(Dispositivo *lista, int tamanho);
void ordenarPorPrioridade(Dispositivo *lista, int tamanho);
void consumoInteligente(Dispositivo *lista, int tamanho, float energiaDisponivel);
void controlarManualmente(Dispositivo *lista, int tamanho);

// Fun��o para trocar dois dispositivos
void trocarDispositivos(Dispositivo *a, Dispositivo *b) {
    Dispositivo temp = *a;
    *a = *b;
    *b = temp;
}

// Fun��o para ordenar dispositivos por prioridade usando bubble sort
void ordenarPorPrioridade(Dispositivo *lista, int tamanho) {
    for (int i = 0; i < tamanho-1; i++) {
        for (int j = 0; j < tamanho-i-1; j++) {
            if (lista[j].prioridade > lista[j+1].prioridade) {
                trocarDispositivos(&lista[j], &lista[j+1]);
            }
        }
    }
}

// Fun��o aprimorada para controle por prioridade
void consumoInteligente(Dispositivo *lista, int tamanho, float energiaDisponivel) {
    // Ordenar dispositivos por prioridade
    ordenarPorPrioridade(lista, tamanho);

    float consumoTotal = 0;

    // Primeiro desligamos todos os dispositivos
    for (int i = 0; i < tamanho; i++) {
        lista[i].estado = false;
    }

    printf("\n--- Dispositivos Ativados/Desativados ---\n");

    // Ligamos dispositivos por ordem de prioridade
    for (int i = 0; i < tamanho; i++) {
        float consumo = calcularConsumoDiario(&lista[i]);

        if (consumoTotal + consumo <= energiaDisponivel) {
            lista[i].estado = true;
            consumoTotal += consumo;
            printf("- LIGADO: %s (Prioridade: %d, Consumo: %.2f kWh)\n",
                   lista[i].nome, lista[i].prioridade, consumo);
        } else {
            printf("- DESLIGADO: %s (Prioridade: %d, Consumo: %.2f kWh)\n",
                   lista[i].nome, lista[i].prioridade, consumo);
        }
    }

    printf("\nTotal de consumo: %.2f kWh de %.2f kWh disponiveis\n",
           consumoTotal, energiaDisponivel);
    printf("Energia nao utilizada: %.2f kWh\n", energiaDisponivel - consumoTotal);
}

// Fun��o para controlar dispositivos manualmente
void controlarManualmente(Dispositivo *lista, int tamanho) {
    if (tamanho == 0) {
        printf("\nNenhum dispositivo cadastrado ainda.\n");
        return;
    }

    int opcao, indice;

    do {
        printf("\n--- Controle Manual de Dispositivos ---\n");
        listarDispositivos(lista, tamanho);

        printf("\n1. Ligar/Desligar dispositivo\n");
        printf("0. Voltar ao menu principal\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        if (opcao == 1) {
            printf("\nDigite o numero do dispositivo que deseja alterar (1 a %d): ", tamanho);
            scanf("%d", &indice);

            if (indice >= 1 && indice <= tamanho) {
                lista[indice-1].estado = !lista[indice-1].estado;
                printf("Dispositivo '%s' foi %s com sucesso!\n",
                       lista[indice-1].nome, lista[indice-1].estado ? "ligado" : "desligado");
            } else {
                printf("Numero de dispositivo invalido!\n");
            }
        } else if (opcao != 0) {
            printf("Opcao invalida!\n");
        }
    } while (opcao != 0);
}

// Funcao para cadastrar um novo dispositivo (mantida igual)
Dispositivo* cadastrarDispositivo(Dispositivo *lista, int *tamanho) {
    Dispositivo *novaLista = realloc(lista, (*tamanho + 1) * sizeof(Dispositivo));
    if (novaLista == NULL) {
        printf("Erro ao alocar memoria!\n");
        return lista;
    }

    lista = novaLista;
    Dispositivo *novo = &lista[*tamanho];

    printf("\n--- Cadastro de Novo Dispositivo ---\n");
    printf("Nome do dispositivo: ");
    scanf("%49s", novo->nome);
    printf("Potencia (em Watts): ");
    scanf("%f", &novo->potencia);
    printf("Horas de uso diario: ");
    scanf("%f", &novo->horasUsoDiario);
    printf("Prioridade (1-Alta, 2-Media, 3-Baixa): ");
    scanf("%d", &novo->prioridade);

    novo->estado = false;
    (*tamanho)++;
    printf("Dispositivo cadastrado com sucesso!\n");
    return lista;
}

// Outras fun��es existentes (mantidas iguais)
float calcularConsumoDiario(Dispositivo *d) {
    return d->estado ? (d->potencia * d->horasUsoDiario) / 1000.0 : 0;
}

void listarDispositivos(Dispositivo *lista, int tamanho) {
    printf("\n--- Lista de Dispositivos ---\n");
    printf("%-20s %-10s %-15s %-10s %-10s %-10s\n",
           "Nome", "Potencia", "Horas/Dia", "Prioridade", "Estado", "Consumo");

    float consumoTotal = 0;
    for (int i = 0; i < tamanho; i++) {
        float consumo = calcularConsumoDiario(&lista[i]);
        consumoTotal += consumo;
        printf("%-20s %-10.2f %-15.2f %-10d %-10s %-10.2f kWh\n",
               lista[i].nome, lista[i].potencia, lista[i].horasUsoDiario,
               lista[i].prioridade, lista[i].estado ? "Ligado" : "Desligado", consumo);
    }
    printf("\nConsumo total diario: %.2f kWh\n", consumoTotal);
}

void controlarPorPrioridade(Dispositivo *lista, int tamanho, float limiteEnergia) {
    float consumoAtual = 0;
    for (int i = 0; i < tamanho; i++) {
        lista[i].estado = false;
    }

    for (int prio = 1; prio <= 3 && consumoAtual < limiteEnergia; prio++) {
        for (int i = 0; i < tamanho; i++) {
            if (lista[i].prioridade == prio) {
                float consumo = calcularConsumoDiario(&lista[i]);
                if (consumoAtual + consumo <= limiteEnergia) {
                    lista[i].estado = true;
                    consumoAtual += consumo;
                }
            }
        }
    }
    printf("\nControle por prioridade aplicado (limite: %.2f kWh)\n", limiteEnergia);
    printf("Consumo total apos controle: %.2f kWh\n", consumoAtual);
}

void simularDecisao(Dispositivo *lista, int tamanho) {
    float consumoTotal = 0;
    for (int i = 0; i < tamanho; i++) {
        if (lista[i].estado) {
            consumoTotal += calcularConsumoDiario(&lista[i]);
        }
    }

    if (consumoTotal > 10.0) {
        printf("\n[Simulacao] Consumo alto (%.2f kWh). Recomendacao:\n", consumoTotal);
        printf("Desligar dispositivos de baixa prioridade para economizar energia.\n");
        for (int i = 0; i < tamanho; i++) {
            if (lista[i].prioridade == 3 && lista[i].estado) {
                printf("- Desligar %s (economia de %.2f kWh/dia)\n",
                       lista[i].nome, calcularConsumoDiario(&lista[i]));
            }
        }
    } else {
        printf("\n[Simulacao] Consumo dentro dos limites (%.2f kWh). Nenhuma acao necessaria.\n", consumoTotal);
    }
}

//Fun��o principal
int main() {
    Dispositivo *dispositivos = NULL;
    int numDispositivos = 0;
    int opcao;

    do {
        printf("\n--- Sistema de Controle de Energia Domestica ---\n");
        printf("1. Cadastrar novo dispositivo\n");
        printf("2. Listar dispositivos\n");
        printf("3. Controlar consumo por prioridade (simples)\n");
        printf("4. Simular decisao automatizada\n");
        printf("5. Consumo inteligente (com ordenacao)\n");
        printf("6. Controle manual de dispositivos\n");
        printf("0. Sair\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                dispositivos = cadastrarDispositivo(dispositivos, &numDispositivos);
                break;
            case 2:
                if (numDispositivos > 0) {
                    listarDispositivos(dispositivos, numDispositivos);
                } else {
                    printf("\nNenhum dispositivo cadastrado ainda.\n");
                }
                break;
            case 3:
                if (numDispositivos > 0) {
                    float limite;
                    printf("\nInforme o limite diario de consumo (em kWh): ");
                    scanf("%f", &limite);
                    controlarPorPrioridade(dispositivos, numDispositivos, limite);
                } else {
                    printf("\nNenhum dispositivo cadastrado ainda.\n");
                }
                break;
            case 4:
                if (numDispositivos > 0) {
                    simularDecisao(dispositivos, numDispositivos);
                } else {
                    printf("\nNenhum dispositivo cadastrado ainda.\n");
                }
                break;
            case 5:
                if (numDispositivos > 0) {
                    float energia;
                    printf("\nInforme a energia disponivel (em kWh): ");
                    scanf("%f", &energia);
                    consumoInteligente(dispositivos, numDispositivos, energia);
                } else {
                    printf("\nNenhum dispositivo cadastrado ainda.\n");
                }
                break;
            case 6:
                controlarManualmente(dispositivos, numDispositivos);
                break;
            case 0:
                printf("\nEncerrando o programa...\n");
                break;
            default:
                printf("\nOpcao invalida!\n");
        }
    } while (opcao != 0);

    free(dispositivos);
    return 0;
}
